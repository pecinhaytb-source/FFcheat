package com.allhack.cheats;

public class NativeBridge {
    static {
        System.loadLibrary("ffhook");
    }
    public static native void setEspLine(boolean e);
    public static native void setEspPlayer(boolean e);
    public static native void setEspHealth(boolean e);
    public static native void setEspSkeleton(boolean e);
    public static native void setFov(int f);
}