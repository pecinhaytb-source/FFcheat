package com.allhack.cheats;

public class NativeBridge {
    // System.loadLibrary("ffhook"); // Removido para compilar o APK sem NDK
    public static void setEspLine(boolean e) {}
    public static void setEspPlayer(boolean e) {}
    public static void setEspHealth(boolean e) {}
    public static void setEspSkeleton(boolean e) {}
    public static void setFov(int f) {}
}