package com.allhack.cheats;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQ = 123;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#0D0D0D"));
        layout.setPadding(50, 50, 50, 50);

        tvStatus = new TextView(this);
        tvStatus.setText("ROOT não verificado");
        tvStatus.setTextColor(Color.GRAY);
        layout.addView(tvStatus);

        Button btnRoot = new Button(this);
        btnRoot.setText("AUTORIZAR ROOT");
        btnRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvStatus.setText("ROOT conectado");
                tvStatus.setTextColor(Color.GREEN);
            }
        });
        layout.addView(btnRoot);

        Button btnFloat = new Button(this);
        btnFloat.setText("ABRIR FLUTUANTE");
        btnFloat.setBackgroundColor(Color.parseColor("#C62828"));
        btnFloat.setTextColor(Color.WHITE);
        btnFloat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), OVERLAY_REQ);
                } else {
                    startService(new Intent(MainActivity.this, FloatingService.class));
                    finish();
                }
            }
        });
        layout.addView(btnFloat);
        setContentView(layout);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        if (req == OVERLAY_REQ && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, FloatingService.class));
            finish();
        }
    }
}