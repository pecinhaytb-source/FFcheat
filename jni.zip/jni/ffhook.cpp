#include <jni.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <android/log.h>
#include <unistd.h>
#include <pthread.h>

#define LOG_TAG "FFHook"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

// Offsets do Free Fire
#define OFF_GET_CUR_HP       0x27a05f0ULL
#define OFF_GET_MAX_HP       0x27a072cULL
#define OFF_SET_AIM_ROTATION 0x274648cULL

bool espLine = false, espPlayer = false, espHealth = false, espSkeleton = false;

// Esconde a thread do anti-cheat
static void hide_thread_name() {
    pthread_setname_np(pthread_self(), "RenderThread");
}

// Aplica o patch na memória (ARM64)
static void patch_ret_imm32(uintptr_t addr, int32_t imm) {
    uint32_t mov_w0 = 0x52800000 | ((imm & 0xFFFF) << 5);
    uint32_t ret = 0xD65F03C0;
    uintptr_t page = addr & ~0xFFFULL;
    mprotect((void*)page, 0x2000, PROT_READ | PROT_WRITE | PROT_EXEC);
    *(uint32_t*)addr = mov_w0;
    *(uint32_t*)(addr + 4) = ret;
    __builtin___clear_cache((char*)addr, (char*)(addr + 8));
    mprotect((void*)page, 0x2000, PROT_READ | PROT_EXEC);
}

static void patch_ret(uintptr_t addr) {
    uint32_t ret = 0xD65F03C0;
    uintptr_t page = addr & ~0xFFFULL;
    mprotect((void*)page, 0x2000, PROT_READ | PROT_WRITE | PROT_EXEC);
    *(uint32_t*)addr = ret;
    __builtin___clear_cache((char*)addr, (char*)(addr + 4));
    mprotect((void*)page, 0x2000, PROT_READ | PROT_EXEC);
}

// Construtor que roda quando o jogo abre
__attribute__((constructor))
void init_ffhook() {
    hide_thread_name();
    sleep(2); // Espera o anti-cheat rodar a primeira varredura

    void* il2cpp = dlopen("libil2cpp.so", RTLD_NOLOAD | RTLD_LAZY);
    if (il2cpp) {
        uintptr_t base = (uintptr_t)il2cpp;
        patch_ret_imm32(base + OFF_GET_CUR_HP, 9999);
        patch_ret_imm32(base + OFF_GET_MAX_HP, 9999);
        patch_ret(base + OFF_SET_AIM_ROTATION);
        LOGI("Stealth Patches Aplicados!");
    }
}

// Ponte JNI pro App
extern "C" JNIEXPORT void JNICALL Java_com_allhack_cheats_NativeBridge_setEspLine(JNIEnv*, jclass, jboolean e) { espLine = e; }
extern "C" JNIEXPORT void JNICALL Java_com_allhack_cheats_NativeBridge_setEspPlayer(JNIEnv*, jclass, jboolean e) { espPlayer = e; }
extern "C" JNIEXPORT void JNICALL Java_com_allhack_cheats_NativeBridge_setEspHealth(JNIEnv*, jclass, jboolean e) { espHealth = e; }
extern "C" JNIEXPORT void JNICALL Java_com_allhack_cheats_NativeBridge_setEspSkeleton(JNIEnv*, jclass, jboolean e) { espSkeleton = e; }
extern "C" JNIEXPORT void JNICALL Java_com_allhack_cheats_NativeBridge_setFov(JNIEnv*, jclass, jint f) {}